var CR7 = 185;
var WildanJR = 161;
var Pessi = 155;

if (CR7 > WildanJR) {
  if (CR7 > WildanJR) {
    console.log('CR7 adalah siswa yang tinggi');
  } else {
    console.log('CR7 adalah siswa tertinggi ke dua');
  }
} else {
  if (CR7 < WildanJR) {
    console.log('CR7 adalah siswa terpendek');
  } else {
    console.log('CR7 adalah siswa terpendek ke dua');
  }
}

if (WildanJR > Pessi) {
    if (WildanJR < Pessi) {
        console.log('WildanJR adalah siswa yang tinggi');
      } else {
        console.log('WildanJR adalah siswa menengah ');
      }
} else {
    if (WildanJR < Pessi) {
        console.log('WildanJR adalah siswa terpendek');
      } else {
        console.log('WildanJR adalah siswa terpendek ke satu');
      }
}

if (Pessi > CR7) {
    if (Pessi < CR7) {
        console.log('Pessi adalah siswa yang tinggi');
      } else {
        console.log('Pessi adalah siswa terpendek ke dua');
      }
} else {
    if (Pessi < CR7) {
        console.log('Pessi adalah siswa terpendek');
      } else {
        console.log('Pessi adalah siswa terpendek ke dua');
      }
}


  

